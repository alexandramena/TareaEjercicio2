class Ingresos:
    def __init__(self):
        self.ingresos = []

    def nIngreso(self):
        nIngreso = int(input("Inserta tus ingresos de hoy: $"))
        self.ingresos.append(nIngreso)
        self.sumIngreso = 0
        self.sumIngreso += nIngreso

    def ReporteIngreso(self):
        for x in self.ingresos:
            print(x)

    def sumIngresos(self):
        print(self.sumIngreso)