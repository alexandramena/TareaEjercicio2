class Egresos:
    def __init__(self):
        self.egresos = []

    def nEgreso(self):
        nEgreso = int(input("Inserta tus egresos de hoy: $"))
        self.egresos.append(nEgreso)
        self.sumEgreso = 0
        self.sumEgreso += nEgreso

    def ReportEgreso(self):
        for x in self.egresos:
            print(x)

    def sumEgresos(self):
        print(self.sumEgreso)