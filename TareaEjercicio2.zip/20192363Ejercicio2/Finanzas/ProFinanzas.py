from Egresos import Egresos
from Ingresos import Ingresos

class Finanzas:
    def __init__(self):
        pass

    def Finance(self):
        nombreCliente = input("Cuenta a nombre de: ")
        print(f"Cuenta a nombre de: ", nombreCliente, "\n")

class Ingresos:
    def __init__(self):
        self.ingresos = []

    def nIngreso(self):
        nIngreso = int(input("Inserta tus ingresos de hoy: $"))
        self.ingresos.append(nIngreso)
        self.sumIngreso = 0
        self.sumIngreso += nIngreso

    def ReporteIngreso(self):
        for x in self.ingresos:
            print(x)

    def sumIngresos(self):
        print(self.sumIngreso)


class Egresos:
    def __init__(self):
        self.egresos = []

    def nEgreso(self):
        nEgreso = int(input("Inserta tus egresos de hoy: $"))
        self.egresos.append(nEgreso)
        self.sumEgreso = 0
        self.sumEgreso += nEgreso

    def ReportEgreso(self):
        for x in self.egresos:
            print(x)

    def sumEgresos(self):
        print(self.sumEgreso)